# Game builder: run settings

V41 first editor, accepted scope: saved guard speeds/vision/attack timings, reinforcement frequency, loot amounts and search times, with defaults reset. Sprite import and room editing come later.

Open the private local server admin link from Terminal. Select a lair, change numbers and click Save settings for next run. No extra installation or public/gameplay editing controls. The screen uses the existing admin buttons, layout, status and backup system. All fifteen fields come from src/tuning.js; that same list defines labels, bounds, defaults, validation and mapping to the real rules. Chances display as percentages; the server stores fractions. Inputs are keyboard accessible and polling preserves unfinished edits in the same lair. Switching lairs loads that lair's saved values. Reset settings to defaults saves immediately and clears any unsaved draft.

Implementation defaults: settings belong to a lair, editable only through private server admin. New groups and older saves use existing balance defaults. Save during a run is allowed: the dungeon copies a complete independent settings object at departure; existing positions, combat, search reservations, loot and bags are untouched. New arrivals see that run's settings. The next departure uses the latest saved values. Multiple groups can have different values and run concurrently. Solo uses the same shared functions with their previous default values.

Editable: patrol/chase/search speeds; normal/alerted sight distances; notice time; attack windup/recovery; whole alerts per extra guard; chest/cupboard/crate search durations; empty-search chance near/far; two-item chance conditional on a nonempty roll. Heat continues to increase chase speed up to its existing ceiling, or retains a manually set speed above that ceiling without slowing it. Personal search bonuses divide the edited duration; difficulty keeps its extra guards/rare/value bonuses. Loot is rolled once at generation, with distance blending unchanged. Guard vision rendering and reinforcement progress use the active run values.

Tuning is durable lair metadata in payload2, included in SQLite checkpoints/full backups. Old saves/backups without tuning use defaults; invalid present settings reject loading/restoring rather than silently replacing them. Settings updates validate the entire field set and bounds before backing up or mutating. Every save/reset makes the existing full before-change backup, then checkpoints; backup failure prevents edits and disk-write failure latches the hub closed. Reset lair/goblin/all progress retains tuning; Reset settings is the explicit balance reset. Full restore restores the backed-up tuning (old backups use defaults). Stock/progress/restore locks still apply while runs are active, independently of the allowed next-run settings edit. No new database schema or dependency.

Checks: domain guard movement/sight/notice/attack, generated loot/search bonuses/reinforcements, concurrent lair/next-run isolation, restart/backup/reset, invalid and forged settings, backup/disk failure, real HTTP/private capability and WebSocket rejection, browser admin form/polling/reset wiring. Automated DOM checks do not claim rendered visual QA. Human test: START-HERE.txt.


V42 extends this with Dungeon generator and floor-plan preview. Both sections reuse src/number-fields.js. Layout settings are saved separately for each architecture in each lair; normal gameplay tuning still applies across its types. See dungeon-builder.md.


V43: Export settings near the selected-lair control downloads saved tuning and all three architecture presets as one version1 green-team-builder-settings JSON file. Save form edits first; export fetches the latest admin summary, excludes unsaved drafts and does not change server state/GitHub. Attach the file in chat to promote chosen values into code defaults. src/settings-export.js uses existing validators and an explicit field projection, omitting codes/keys/progress and preview seed/difficulty. Chance values in JSON are fractions as in code, even though the UI shows percentages.

When promoting an attached export, validate format/version and the complete tuning/generator values, map tuning fields back into their existing groups in src/config.js, and update the three presets in src/generator-settings.js. Preserve unrelated constants and record intended balance changes/checks. Existing lairs retain their saved overrides; defaults apply to new lairs and explicit defaults reset. Do not commit private server backups instead of the settings file.


## V67 early-loot defaults and existing lairs

Run settings now include Materials near entrance, displayed as a percentage like the empty-search fields. New defaults: near-empty45%, far-empty35%, near-material55%. Other loot endpoints and progression prices are unchanged. Changes save for the selected lair's next run; active runs retain their captured tuning. Exports include the field and identify V67.

Old saved editor settings keep their chosen values and receive near-material75%, matching the previously fixed source value. A pre-update backup is made before checkpointing the expanded settings. Backups with the old exact field set remain readable/restorable. Incomplete or invalid current submissions remain rejected. Existing lairs can opt in by changing just the three loot fields to45/35/55and saving; avoid Reset settings if retaining other custom tuning. Lairs with no stored tuning use current defaults.
