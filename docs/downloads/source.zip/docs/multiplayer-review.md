# Multiplayer rules review

Status: discussion draft, 17 October 2026. V21 remains the current playable prototype.

The user requested a pass over multiplayer questions that should accompany feature planning. This reviews the systems already in the game. Recommendations below are proposals, not accepted requirements. Discuss a small batch at a time; record answers here and in decisions.md. Server setup and multiplayer playtesting are still deferred.

## Already agreed

- One player controls one goblin; everyone plays through a browser.
- The team lair has shared gold, materials, crafted stock and recipe unlocks. Personal carried sacks hold separate item copies.
- Successful return sells valuables and deposits materials/unused gear. Taking supplies uses lair stock. Debug items do not create real stock.
- Goblins can trigger/waste armed snares without being harmed. A newly placed snare waits for its setter to step clear.
- Team extraction requires all standing participating goblins together; downed goblins are excluded from the leave counter. A teammate can revive a downed goblin to one health using a Packed Lunch. Downing spills sack contents as recoverable floor items; the revived goblin can pick them up again. Exact handling of an unrecovered goblin remains open.
- Guards capture downed goblins into the nearest preplaced cage, prioritising standing goblins in sight. Allies can rescue captives; cage sites have a largely stationary jail guard. Capture interruption and cage-release details remain open.
- Keep the game lightweight for inexpensive hosting. No working multiplayer or shared online save exists yet.

## Batch 1 — choosing and starting a job

Accepted by the user, 17 October 2026:

| ID | Decision | Agreed rule |
|---|---|---|
| A1 | Who chooses job and difficulty? | Anyone can interact with a map-planning station in the lair. The latest confirmed selection stays selected until someone changes it. This replaces team voting. |
| A2 | Readiness / departure | Everyone readies at a separate minecart departure point. Ready means ready to go, not approval of a destination. Map/difficulty edits do not clear readiness; departure uses the latest selection. |
| A3 | New arrivals during a run | Wait until the next run. Reconnecting an existing goblin is a separate question. |

The lair has distinct functions: stash, workbench, map-planning station and departure minecart. The cart sits on tracks leading into darkness as the travel theme. Keep the selected destination/difficulty visible so teammates know what they are preparing for. Do not implement a vote or host-only selection gate. Tie-breaking is no longer relevant.

Confirmed clarification: even if someone readies on Normal and another changes it to Hard, readiness remains and the party departs on Hard if that is the selection when the cart leaves. Do not add a reset, destination approval or confirmation gate. Freeze the live run profile at actual departure.

Confirmed cart interaction: E boards/marks ready; E again hops out/unreadies. When all participating goblins are aboard, start a three-second countdown. A goblin hopping out cancels it. Destination changes still do not clear readiness.

Remaining preparation follow-up:

- Implemented locally in V30: stash/workbench packing first, separate map confirmation, then board the cart. Planning never starts the dungeon or spends gear; the final departure moves the prepared bag once. Online coordination remains future work.

One job profile/seed must be frozen for the departed run and shared by everyone. Subsequent edits at the planning station cannot alter a live dungeon. New arrivals still wait for the next run. Server implementation remains deferred.

“Host” means the person organising the session. It does not mean their browser must simulate the game or their computer must host the server. An inexpensive shared server remains the intended hosting direction; technology/setup choices are not made by this review.

## Batch 2 — escape, downing and recovery

Accepted user answers, 17 October 2026:

| ID | Decision | Agreed rule |
|---|---|---|
| B1 | Leaving | All standing participating goblins must be together to leave. Downed goblins do not count toward the leave check, so survivors can leave without them. No individual extraction/banking while another standing teammate continues. |
| B3 | Ground revival | A teammate can revive a downed goblin to one health using a Packed Lunch before capture. Player-carrying a downed goblin out is not allowed. Restoring a goblin to standing adds it back to the extraction count. |
| B5 | Capture / jail rescue | A guard picks up a downed goblin and carries it to the closest preplaced cage. Cage locations are fixed for that generated map and have a largely stationary jail guard. Allies can rescue from cages, restoring one health without a Packed Lunch, at greater risk than a coordinated ground revival. A carrying guard that sees a standing goblin drops its captive and chases the standing goblin. |
| B6 | No rescuers left | When no standing, free goblins remain, end the failed run and return everyone to the lair. Loot left behind is lost. |
| B7 | Rescue interaction | Hold E on the teammate or cage. Moving or taking damage cancels. Packed Lunch is consumed only when a ground revival completes; interrupted attempts keep it. |
| B4 | Sack on downing | Sack items spill onto the floor immediately. They can be picked up again, including by the goblin after recovery. Do not delete them at downing or automatically restore a packed sack on revival. |

Unresolved before implementation:

- Packed Lunch crafting/unlock cost and cage opening duration are still unset. Ground revival uses the previously proposed three-second hold; interruption cancels progress. Consumption on completed ground revival and preserving the lunch on interruption are now agreed.
- Repeated revival limits, pickup delay/interruptions, how many goblins fit in a cage, jail-guard pursuit limits and whether a delivered guard returns to its original routine. No bleed-out timer or self-escape rule has been chosen.
- Group exit interaction/countdown/required proximity; do not automatically copy the departure-cart countdown onto extraction.

Implementation proposal: choose the nearest reachable preplaced cage by walking-route distance, reusing navigation. Guards transporting a captive move that goblin’s body; previously spilled floor loot remains where it fell. Dropping a captive returns that goblin to the downed state at the carrier’s current location; do not create another body or move/respill the loot originally dropped. This state handling follows the agreed drop-and-chase behavior. Pickup and cage opening timing still need tuning.

Implementation notes: transfer bag contents to ground exactly once per down event, preserve item IDs/metadata/debug tags and clear the bag. The quick-use equipment display is a reference to a carried copy, not another item to duplicate. Recollection uses normal floor pickup and sack fitting. Proposed held-cursor behavior: drop that carried item too. Future loss settlement should concern items actually left behind, not also delete a copy already recovered by a teammate. Successful survivor-group extraction banks/sells only the escaping goblins' actual carried contents once. Downed goblins remain left behind; floor items teammates recovered belong to those actual carried copies and must not also be lost/deleted by prior ownership.

## Batch 3 — joining, leaving and connection loss

| ID | Question | Recommended starting rule | Alternative |
|---|---|---|---|
| C1 | How many friends is the first supported party? | Four, with counts/difficulty tuned for that target. | Another explicit limit; do not assume unlimited. |
| C2 | What if someone's connection drops? | **Agreed:** grey/translucent goblin for 60 seconds; guards ignore it and players cannot interact. Reconnect restores the same goblin immediately. Timeout spills its sack and removes it from this run. | Supersedes the vulnerable-disconnected-goblin proposal. |
| C3 | What if the session host leaves? | Transfer organiser controls to another player; do not erase the lair or restart the world. | Pause launch/await a designated owner. |
| C4 | Can a player deliberately leave or abandon? | Leaving affects their goblin/gear; one player's button cannot silently abandon the whole team's run. | Team-abandon action with an explicit group rule. |

C2 agreed details: when the game detects disconnection, start a 60-second grace timer and show that goblin grey and see-through. Guards cannot see/target/hit the disconnected goblin, and teammates cannot interact with it. Reconnection before timeout restores control and ordinary visibility immediately, with no extra protection from nearby guards. Preserve its sack and goblin identity rather than granting a new loadout. At timeout, spill its remaining sack contents once and remove that goblin from the current run, as accepted from the preceding proposal. A later arrival follows the existing wait-for-next-run rule. Repeated reconnects must never duplicate gear, floor loot or rewards.

Agreed: disconnected goblins are excluded from the group departure counter throughout the 60-second grace period, so they cannot block connected survivors leaving. Reconnection during an ongoing run restores the normal standing-player departure requirement. Agreed: if connected survivors leave before a ghost reconnects, that disconnected player returns to the lair without its dungeon sack; it receives no sale/banking reward for items left behind. A later reconnect joins the lair rather than resuming the finished dungeon. Items already recovered and carried out by a teammate are settled normally and never deleted by former ownership. Agreed exception to no-free-standing-player failure: if the only remaining standing goblin is disconnected, keep the run open for its remaining 60-second grace, not a fresh timer. Reconnecting allows play to continue; expiry with no standing rescuer ends the run as a loss. With several standing ghosts, use their existing individual timers and fail only when none remain eligible to return. Downed/carried/caged ghosts do not gain standing status from disconnection. Still pending: disconnect while downed/carried/caged/hidden; interrupted interaction/reservation cleanup; repeat-disconnect grace policy. Reconnect should preserve prior health/recovery state, not silently revive a goblin, but exact special-state rules require review. Connection loss must not reset dungeon heat/alerts/reinforcements or pause the shared world. This is future multiplayer behavior, not implemented in V24.

## Batch 4 — searching and carrying loot

| ID | Question | Recommended starting rule | Alternative |
|---|---|---|---|
| D1 | Can two goblins search the same container? | **Agreed:** one active searching goblin per object; contents spill once. | Cooperative speedup not selected. |
| D2 | Can goblins exchange equipment and valuables? | **Agreed:** drop on the floor; teammate picks up using existing controls. | No direct trading screen needed. |
| D3 | Should goblins collide with each other? | **Agreed:** goblins pass through each other to prevent doorway blocking. | Solid teammate collision not selected. |

Engineering default to verify rather than ask as a game preference: two simultaneous pickup attempts cannot both receive the same item. A full sack never consumes someone else's pickup or loses floor loot. Another player's cursor/reticle is local UI, not a claim on an item.

## Batch 5 — shared gold, stash and preparing gear

| ID | Question | Recommended starting rule | Alternative |
|---|---|---|---|
| E1 | Can everyone spend shared gold on future lair improvements? | Everyone can; show the team what was purchased. Personal recipes now derive from each goblin’s XP, not shared gold. | Host-only group purchases or approval above a threshold. |
| E2 | When are prepared supplies taken out of shared stock? | **Agreed:** transfer immediately from stash into personal sack; putting back restores stock. First successful transfer gets the last copy. | Launch-time reservation model superseded. |
| E3 | What if two people rearrange the same stash stack? | Briefly reserve that stack for the mover; others can use the rest of the stash. | Allow moves to fail cleanly when another change wins. |

Crafting, purchases and withdrawals must validate against the same shared quantities in one operation. Agree whether a moving stack also blocks crafting with its materials. Whole-stack movement cannot hide available stock forever if its player closes the panel or disconnects. One gold stack and its displayed balance remain the same quantity.

Agreed preparation flow: each goblin packs its own sack at the shared stash before boarding the departure minecart. Taking an item transfers that actual copy immediately out of shared stock into the goblin's sack; putting it back reverses the transfer. If two players try to take the last copy, only the first successful transfer gets it. A full sack rejects the transfer without spending stock. Departure must not deduct packed supplies again. This replaces reservation-only preparation as the chosen flow; V27 implements the local direct-packing flow and removes the quantity picker; online team coordination is still future work.

Crafting output correction, agreed: crafted items go into the crafter's personal sack first if they fit. Shared-stash overflow was subsequently explicitly approved and implemented in V27. Use existing sack footprint/fit rules; never consume materials unless the output has a valid destination. This supersedes the proposed always-to-shared-stash output. Where a recipe/progression belongs is now actively under reconsideration; do not mark the previous shared-recipe recommendation newly accepted.

## Batch 6 — guards, traps and team information

| ID | Question | Recommended starting rule | Alternative |
|---|---|---|---|
| F1 | Does one spotted goblin alert every guard? | Guards react locally; they can change targets to a goblin they actually notice. | Room alarms or dungeon-wide alert, with explicit propagation. |
| F2 | How do guards choose between goblins? | Prefer their current visible target; switch when it escapes sight or another target is clearly nearer. | Always nearest visible player. |
| F3 | Do quick items/attacks affect teammates? | Smoke hides all goblins; snares waste harmlessly under any goblin as agreed. Decide damage items separately when added. | Other explicit friendly-effect rules. |

Per-player damage immunity, knockback and attack direction must remain separate. A guard's invisible trail belongs to its pursued target, not whichever browser updates last. Smoke must obstruct the same sight checks for everyone. Placement safety follows the actual setter's identity. No secret map/guard information should leak through another player's local UI unless the team intentionally shares it.

## Heat and reinforcements — V24 local implementation

Agreed: shared dungeon heat rises during sustained pursuit, including fresh trail-following, holds through brief sight breaks, and slowly cools after a grace period without pursuit. Higher heat gradually increases alerted guards' chase speed, capped just above goblin running speed at maximum heat. Keep routine routes and attack timing predictable; heat never reveals hidden goblins. Show readable heat feedback. Exact rates, delay and speed cap remain tuning parameters.

User additionally requested one extra guard entering the dungeon for every three chases/alerts. Reinforcements remain for the rest of that run: cooling heat does not remove them. The accumulating guards create increasing run pressure, eventually making continued looting/escape overwhelmingly difficult. Do not silently cap the guard count to negate that intended pressure. No automatic elapsed-time reinforcements were requested.

Agreed counting: each individual guard becoming alerted adds one to the shared run counter. Two guards catching the team together add two counts; three add three and bring one reinforcement. This intentionally makes being spotted by multiple guards substantially more dangerous. The previous recommendation to combine simultaneous guard alerts into one team incident is rejected. Every third guard alert adds one guard; carry any remainder forward, and retain the counter through heat cooling.

Count when each guard becomes fully alerted, not when the chase ends or each frame. A guard rearms only once it has finished searching and returned to its routine; brief sight breaks/reacquisition stay in the same alert cycle. Witnessing a completed hiding entry also fully alerts that guard and counts once. This follows the accepted proposal; no counting per player/browser.

Agreed reinforcement entrances: doors in some rooms' upper walls, not interactable by goblins. New guards are roaming patrol/searchers. V24 chooses solid north-wall sections, excluding the starting room, with a brief two-second warning at the selected door and in the HUD. Doors cycle in fixed order. Each guard caches a broad room sweep, pauses to look around and uses existing sight/chase/trail/attack/snare/smoke/hiding rules; no unseen-player location knowledge. Extra guards last for the run without a population cap.

Provisional HEAT values: full buildup in 30 seconds of pursuit, four-second quiet grace, full cooling over 20 seconds, maximum chase speed 1.08× goblin speed; routine/search speeds and attack timing unchanged. HUD shows heat, total alerts/remainder, extra guard count and pending arrival. State resets on a new run; lair/finished runs do not tick it.

Before networking, the server must count each guard's alert cycle once, tick one shared heat state and spawn queue once for the whole team, and send stable guard/door IDs and warning times to all browsers. One goblin hiding cannot cool heat while another is pursued. Joining/reconnecting must receive current state without replaying alerts/spawns. Difficulty/party scaling and jail-guard interaction remain open. Detection stays local even though pressure is shared. V24 is local runtime, not multiplayer implementation.

## Hiding — playable local slice, team details pending

Agreed: hold E for 0.5 seconds to enter, tap E to exit; one goblin per spot with a visible occupied indicator; no walking, searching or item use inside; guards that see entry approach and pull that goblin out; unseen entry is safe during nearby searches. V22 implements this locally with separate barrels and existing targeting/navigation/sight. V24 now adds local heat/reinforcements.

Prototype stores stable spot IDs, occupant ID and per-guard witness knowledge tied to a goblin ID. One occupant per barrel is now explicitly agreed. V23 also checks occupancy again at entry completion, so concurrent local attempts cannot both succeed. Before shared play, make reservation/release atomic on the server; decide disconnect/downing cleanup and how a witness prioritises a visible teammate. A hidden goblin must not stop guards pursuing others, reveal its location to non-witnesses, or independently cool team heat while others are chased. Current guard update remains single-target; do not call it once for every player as a substitute for target selection.

## Batch 7 — progress, difficulty and running the session

| ID | Question | Recommended starting rule | Alternative |
|---|---|---|---|
| G1 | Whose lair/save is this? | **Agreed:** a persistent named home for each friend group, stored on the server independently of the organiser being online. Personal goblin progress travels between groups. | Invitation-host-owned lair not selected. |
| G2 | Does difficulty scale with party size? | Keep job/difficulty fixed for the run; consider scaling only at launch after comparing solo/team balance. | Fixed counts for every party size, or another explicit scaling rule. |
| G3 | Does retrying a job produce a new layout? | Each new run uses a new seed; reconnect uses the same live run. | A retry reuses the previous seed/layout. |
| G4 | Do menus or an unfocused browser pause the game? | Personal menus never pause the shared world; all-ready launch controls preparation. | A separate explicit team-pause rule. |

Define crash/restart recovery and update timing before hosting. Recommended operational starting point: durable lair transactions, no duplicated run settlement, game updates between runs, and a visible save/connection state. Whether to resume an interrupted dungeon or treat it as a lost run is a user decision, not a technical accident.

## Implementation responsibilities after answers

- The shared server is the single place that decides world state and outcomes; browsers send player actions and draw the result. This is a design direction, not server code added now.
- Stable IDs for lair, session, run, player, goblin, container, item and placed effects.
- One run seed/job/difficulty and one set of guard/effect timers for everyone.
- Prevent duplicate pickup, craft, unlock, supply reservation and escape settlement, including repeated/reordered requests.
- Separate party state (selection/readiness) from each goblin's state (alive/down/escaped/disconnected) and each person's local UI.
- Team-ready or extraction requirements must not accidentally include spectators or people waiting for the next run.
- Co-op-specific checks should cover simultaneous use, player departure and reconnection, not only one browser acting successfully.

## Audit evidence

| Current source | Solo assumption to revisit |
|---|---|
| main.js + loadout-view.js | A local job dropdown and Start immediately spend one sack's supplies and create the entire world. |
| run.js | One goblin's extraction/downing finishes the run. |
| lair.js | Browser-local counts/save; no simultaneous reservations or purchase arbitration. |
| loot.js + search.js | One cursor, one bag and one active search session. |
| guard.js | One player argument, one lastSeen/trail target and one damage recipient. |
| traps.js | Multi-goblin trigger list exists, but current main uses one fixed goblin ID. |
| smoke.js + render.js | Shared effect mechanics are reusable; the current cloud list/timers are browser-local. |
| input.js + stash-view.js | Menu focus/readiness/stack movement are local and need clear per-player ownership. |

The current prototype remains useful to test feel, but these assumptions must not be treated as the agreed multiplayer rules. Follow the batches above before implementing their related team behavior. Revisit the checklist when adding a new feature; do not turn it into an endless precondition for unrelated small fixes.


## Networking setup — server-based direction agreed

User considered P2P, then accepted the server-based recommendation. The shared dungeon runs independently of player browsers on a rented server, using Node.js, secure WebSockets/HTTPS and SQLite for durable shared-lair storage as the starting stack. No network code or hosting has been implemented. Colyseus remains a framework candidate, not a selected dependency; provider, budget, machine size and party limit remain open. Earlier server-responsibility notes now describe the chosen architectural direction.

Agreed starting dedicated setup: one continuously running Node.js game process using secure WebSockets, HTTPS delivery of browser files, and durable shared-lair storage (SQLite is the agreed starting storage choice, with backups). It owns guards, heat, counts, loot and saves independently of any player's browser. A small virtual server can host these together; actual capacity must be measured with growing guard populations. Colyseus is an existing framework candidate, not an adopted dependency. Static website hosting alone cannot run this continuously active game process.

P2P candidate: browsers exchange gameplay over WebRTC; for this shared-rule game a practical design still chooses one browser as the authority. Provide website hosting, a small signaling service for room/connection introductions, STUN discovery and TURN relay fallback where direct connections fail. Durable shared saves still need an explicit ownership/storage policy. If the authoritative browser leaves, transferring its latest game state and authority requires a separate host-migration design. Relaying traffic also has hosting/bandwidth costs; do not promise server-free or always-cheaper P2P.

References: https://webrtc.org/getting-started/peer-connections ; https://webrtc.org/getting-started/turn-server ; https://docs.colyseus.io/deployment ; https://docs.colyseus.io/server . The server-based direction and starting stack are agreed; no deployment or purchase is authorised. Multiplayer implementation/testing remains deferred until its playable slice is explicitly started. The P2P comparison is retained as background, not the current implementation plan.


## Personal progression and persistent group homes — direction agreed

User selected a persistent home for each friend group and said to run with the preceding split. Each named lair persists on the chosen server across logout, rather than belonging to whoever currently invites/hosts. Players can be members of several distinct lairs and choose which one to join through its invitation/link/code. Personal goblin XP/level, learned recipes and personal improvements/cosmetics travel with the player. Gold, shared materials, crafting stations and decorations belong to that group lair. Logging out does not erase either save.

Progression direction: personal XP unlocks learned recipes; shared gold improves lair facilities. A visiting experienced goblin brings recipe knowledge but still needs the local station/material requirements. This supersedes gold-buying-shared-recipes as the final progression design; V24's existing gold recipe purchase remains a prototype until the new progression slice is defined and implemented. No XP amounts, level thresholds, upgrade effects or station prices accepted yet.

Still open: account/reconnect identity, creator/member permissions and invitation revocation, offline access policy, personal gear/material portability and disconnect-held sack persistence, exact XP earning/distribution, unlock levels and how facilities gate recipes. Distinct group stock must not be duplicated across homes. Agreed personal XP: everyone participating in the run receives the same XP based on the team's recovered loot, regardless of which goblin picked up/carried it. This includes participants downed/captured/left behind; waiting new arrivals are not participants. Do not grant extra XP for personally claiming a teammate's pickup. Exact reward conversion, failure rewards, disconnected participant eligibility, thresholds and unlock schedule remain to define. Settle the team's actual recovered haul once, then credit each eligible personal profile once; reconnect must not replay the reward. Resolve these within a bounded progression slice before implementing accounts/rewards.


## V25 personal XP playable slice

User approved a bounded XP display/results/separate-save test. Provisional rate: one XP per gold of recovered valuables, reusing item sale values/Hard rounding. Materials, equipment/debug gear, empty escapes and solo losses produce no XP in this slice. Personal XP never decreases due to spending shared gold or losing a later run. No new level/unlock thresholds chosen. This is experimental pacing, not a final reward schedule.

Implemented local personal profile separate from lair storage. Reward calculation accepts a team haul and can credit multiple distinct profile IDs equally once per live result; tests cover that shared-haul calculation, not online multiplayer. Current UI still plays one goblin. Future server must use durable identities/run IDs and transactional rewards, with disconnected eligibility and failure bonuses decided before team implementation. Named lairs/account login, gear portability, crafted-output transfer and personal recipe unlock conversion remain future slices; do not imply these are implemented by the separate local save.


## V26 personal recipes implemented locally

User approved starting snares, automatic smoke knowledge at 50 total personal XP, no XP spend, unchanged material costs and workbench progress. Replaces the old gold-bought shared smoke recipe. Each craft checks the acting goblin's profile and shared materials; recipe knowledge is not a lair flag and one goblin learning/crafting never unlocks another. Existing shared gear remains usable without recipe knowledge. Thresholds are editable starting balance.

Camp schema3 removes shared unlock flags, preserves stock/layout and refunds the prior schema2 smoke purchase's 20 gold once. No XP granted for migration. Personal knowledge derives from the separate profile's saved XP. Crafted output is still the current solo shared-stash path; agreed sack-first crafting/direct transfer and named-home/server account UI remain planned, not implemented by this recipe slice. Server must eventually validate profile knowledge and spend shared materials/output once as one transaction.


## V27 direct packing and crafting overflow implemented locally

User approved shared-stash fallback when a crafted item cannot fit in the crafter's sack. V27 implements this with immediate stash-to-sack and sack-to-stash transfers, existing footprint/rotation fitting and one carried copy per item. Crafting consumes shared materials once, then prioritises the sack and otherwise stores output centrally. Cancelled departure retains gear, and actual departure never withdraws shared stock again. Quantity selection is removed; job/difficulty remains at the local departure screen for now.

Single-player local save schema4 persists the prepared bag and stock together and clears the saved prepared bag on launch. This is not the final shared storage structure: future server must key prepared bags by lair/player, generate shared unique item IDs, validate each transfer/craft/departure against live ownership, and commit quantities/output/stock once atomically. No client can claim another's packed copies. Group joining, creator/member permissions, disconnect handling for packed home gear, map-planning station and all-board cart readiness still require implementation/remaining review. Current debug supplies cannot generate real shared stock.


## V28 spendable personal XP supersedes automatic knowledge

User explicitly changed XP into a spendable personal resource and approved the first purchases: smoke recipe50 XP and permanent10% faster searching passive30 XP; snare starts known. This supersedes V26 automatic50-total-XP recipe acquisition. Buying deducts available personal XP once and stores explicit ownership; crafting thereafter uses shared materials only. Current workbench reuses recipe-card/button UX for purchases, ownership, crafting and passive display. Shared lair gold is unaffected.

Profile schema2 separates available XP, lifetime earned XP and owned purchases. Old schema1 saved XP becomes available balance and existing automatically learned smoke knowledge is preserved as a migration grant. New profiles must buy it. Current local server-free save is not account identity. Future backend must validate profile identity/balance and atomically debit/record each one-time purchase, never trust a browser's claimed owned list/search rate. Search duration is derived from the acting goblin and the same value drives its progress bar; teammates' profiles cannot be upgraded by another's purchase. Reward replay cannot replenish spent XP. No tiers/respecs/additional passives chosen.


## V29 passive upgrade station

User requested personal passives at a little lair campfire instead of the workbench. Implemented campfire station and a compact mode of the existing lair dialog: personal XP/passives only, same purchase/save rules. Recipe buying/crafting stay at the workbench. Neither station grants knowledge or passives to other goblins. Future server purchase commands must validate station/action and acting personal profile; no new multiplayer behavior or save change introduced.


## V30 map station and cart implemented locally

User approved the next slice using the already-agreed map/boarding rules. Upper-left map table confirms/saves the selected job/difficulty without starting; separate cart E toggles aboard, starts three seconds once all eligible participants are aboard, and E hop-out cancels. Editing selection preserves readiness/timer. The final departure uses the latest confirmed profile and generates one seed; later planning cannot mutate that run. Shared stock is not deducted twice and cancelled planning/boarding leaves prepared gear intact.

The coordinator supports an explicit participant list and excludes unlisted waiting arrivals. Current UI supplies one local goblin; no networking or simulated extra players added. Future server must own participant membership, proximity-valid boarding, clock, selection updates and one atomic launch. Menus in another browser must not pause that server countdown. Persist selected destination, not readiness/timers. The local confirmed destination saves in camp4; legacy saves default to Normal. Existing disconnected/late-arrival policies still require network integration, not new assumptions in this local slice.


## V31 shared-home network test

User approved the first actual two-client test. Node + ws now runs authoritative home movement, stock transfers, station-validated crafting/purchases/maps, separate bags and shared cart coordinator. Browser sends commands/inputs, not quantities/positions/elapsed time. Last-copy takes and crafting execute synchronously on the shared state. Server snapshots expose only the acting goblin’s profile/bag plus shared stock/other goblin poses. Late arrivals after the shared launch checkpoint wait. No team dungeon runs or rewards exist yet.

This local-only test has one memory-only home and temporary per-tab identities; it does not implement persistent friend groups, account security or SQLite. Offline home goblins retain their bag in memory and leave ready membership; reconnect returns same bag. Changed membership cancels countdown until a fresh boarding action. Test return button resets all goblins to home after checkpoint. Dungeon disconnect/ghost/capture/extraction rules above remain unchanged and unimplemented. Public deployment, final lair disconnect policy and reconnect abuse rules still need work.


## V32 shared dungeon slice

V31 human playtest passed: user confirmed movement, shared stock and boarding/cancellation. V32 adds the approved shared map/search/loot slice. Node owns one dungeon, searches/leases, floor items, separate bags/held items, collision and extraction/banking. Client recreates deterministic layout from server seed only for rendering; requests never set stock, positions, loot types or search time. Snapshots omit unrevealed container contents and other players' private bags/profiles. One container is reserved per active search; release/move/stale input/disconnect frees it. Shared pixel bar is visible to both players. First successful pickup/lift gets one actual item; full-bag failure leaves it on the floor. Ground/bag lifting, rotate/place/drop reuse existing item rules, with reach/ownership/fit rechecked server-side.

Team tunnel departure uses agreed togetherness with no invented extraction countdown. All connected participating actors must be near the tunnel, with hands clear. Settle once, bank only their packed recovered haul, return all to home, keep waiting newcomers out of prior rewards/loot. Results use same component with team slot counts. Network XP remains disabled and visibly labelled until its own transaction slice; final equal-participant XP direction remains agreed.

Standing-goblin dungeon reconnect:60seconds ghost, no interaction, not exit blocker, same actor/bag on timely return; expiry spills bag/held once and moves to waiting. All-offline run stays open until no eligible ghost remains. Survivor extraction does not bank offline sacks; late reconnect cannot restore closed dungeon. These checks use detected WebSocket close; silent transport failure heartbeat, repeat grace abuse, downed/carried/caged/hidden cases remain unimplemented. No guard vision exists in this slice; do not claim guard ghost immunity has been tested online. No durable/server restart recovery.


## V33 networked danger loop

User approved a larger bundled guard/combat/pressure/hiding/snare/smoke milestone after successful V32 human playtest. server/team-guards.js chooses one focus and calls core updateGuard once per guard/step; never tick it once per goblin. Prefer the current visible target, otherwise nearest visible eligible actor, known witnessed hiding, or current target for its existing short trail. A committed swing cannot retarget; its directional arc can hit other active bodies inside it. Fallback unavailable actor advances routine/search without generating fictitious sight/trail or damage when all goblins are hidden/down/disconnected. Shared pressure counts the same guard cycle once despite target switches and spawns one shared reinforcement every3alerts.

Server/danger.js coordinates existing health/knockback, guard/pressure, half-second hiding, reserved-item trap placement/arming/triggers and smoke. Each timer is updated once, shared snapshots carry poses/attack phases/health/heat/door warnings/clouds/traps/barrel occupancy, while only the owner receives placement/quick-use UI state. One barrel accepts one completed entry. Any witness during entry may remember and expose that goblin; another visible goblin can distract it. A hidden teammate never prevents other guards noticing standing teammates. One hidden goblin cannot make shared heat cool while another chase exists.

Equipment uses existing E selection/equip, WASD aiming, release-then-holdE1sec placement, Esc cancellation and Space smoke. Client preserves actual held E across equip so autorepeat cannot bypass release; pointer aim transmits only after pointer changes so it does not fight keyboard aiming. Server checks real bag ownership, finite/clamped aiming, valid space/obstacles, full placement duration, owner clearance and live triggers. Two overlapping placements cannot both finish. Smoke spends one carried copy and blocks shared sight without blocking a committed strike. Local Debug supplies reuses existing tagged free supplies, never shared stock/currency.

Downed bodies drop sack/cursor once, cannot act, are ignored by guards/traps, and do not count to standing exit. Survivor settlement banks actual recovered copies only; left-behind results omit anything carried out by a teammate, including unused gear. If all standing goblins are down, fail except for existing remaining active-ghost grace; reconnect does not revive a downed goblin. Full health is restored only at home for the next run. Packed Lunch, cage/guard carrying and rescue are still next, not implied by this milestone.

Temporary hidden-disconnect cleanup choice: release occupancy, put ghost at outside entry, cancel entry/placement, keep health/bag; reconnect outside with normal visibility. Existing hit immunity expires offline; no new immunity/healing granted. Ghosts cannot trigger traps or yield fresh footprints. These cleanup/target/arc defaults remain adjustable after playtest, and repeated grace abuse/heartbeat/durable restart policy remain open.


## V34 revival/capture/cage implementation

User explicitly requested revival and cages. A standing rescuer holds E on a reachable downed teammate, using an actual Packed Lunch copy from their own sack on completion only. Both floor and cage rescue restore1health, no free inventory refill or added invulnerability. Revived goblins again count toward standing extraction. Floor loot from earlier downing remains recoverable at that original spot. Holds cancel on release/movement/damage/target movement or state/reach/disconnect/missing item/competing interaction. One helper per goblin prevents duplicate cost or restore, while separate captives may be helped independently.

Guard pickup/carry reuses walking navigation. Eligible ordinary guards must see the downed body, prioritise any visible standing goblin and claim one body each. Nearest cage is chosen by reachable walking path, with deterministic tie-breaking; carried body follows guard pose. A standing goblin seen during transport causes the guard to drop the same downed goblin at its current position and chase, without moving or respilling the original loot. Snares pause carriers. Cages have dedicated stationary jailers using the same sight/attacks/pressure counters; they do not pick up prisoners. Map generation chooses cages/posts away from the entrance, furniture/hides and existing guard homes, and checks walkability/reachability.

V34 defaults in RESCUE:2sec revive,3sec cage opening,1sec pickup,1.6tiles/sec carry, up to3 cages. Multiple captives may share the nearest cage; each completion releases one. These are provisional choices, not new fixed user requirements. Packed Lunch uses1 sack slot and is available in existing local Debug supplies; its crafting/material/recipe/XP price remains undecided. Lunch metadata flows through standard stash/bag/save/item rendering and debug no-credit rules.

Carried disconnect drops as a downed ghost and clears carrier claim; caged disconnect retains the cage/health state but is ineligible for rescue until connected. Expiry/closed run clear cage membership/carrier/helper reservations and never revive or respill the original bag. A downed/carried/caged ghost cannot prolong failure as a standing rescuer. Proper account identity, active heartbeat detection, durable recovery, repeat-grace abuse and persistent rewards remain future stages.


## V35 carrier sight correction

V34 received user playtest approval with one correction: a guard carrying a teammate must look forward so another goblin can follow behind. Server carrier checks now reuse shared sight with forward-only mode, suppressing both alert all-around detection and the close-range rear exception. The actual captive claim controls the first post-pickup tick too. Walls/smoke still block forward detection; a visible goblin ahead still causes drop-and-chase. Renderer shows the matching normal-range cone. Other guard states retain their existing rules.


## V36 durable home and local identity recovery

User approved the persistent shared-lair slice. Shared stock/gold/slots/destination and all personal home sacks/profiles are saved together in one SQLite row before acknowledgement. Launch projects participating bags as empty in the durable home; normal in-memory dungeon/reconnect rules continue unchanged until that run closes. Restart therefore returns interrupted participants home without their spent supplies or unbanked loot. Waiting arrivals' prepared bags stay saved. Extraction commits banked real recovered copies and cleared sacks once. This restart policy is an implementation default stated to the user, not a newly invented crash-recovery promise.

Browser local identity registry and per-tab selections restore existing goblins across server/browser restarts without touching solo saves. Duplicate live identity still becomes a distinct test goblin. Home-only selector lets testers choose prior goblins; selection is disabled during a run. Tokens never appear in another player's snapshot; save files are excluded from HTTP/static serving and Git/ZIPs. One default home/database per server, not yet group joining or secure accounts. Network XP settlement remains disabled. Local identity keys are bound to browser/address storage; account recovery across devices remains open.

Unreadable/unsupported saves fail visibly at startup. Write failure blocks further session mutations, pauses live simulation, closes clients with save-error feedback and never acknowledges the failed transfer. Copy data only with server stopped for updates/backup. SQLite uses full synchronous single-statement commits; movement-only checkpoints compare equal and do not write. Concurrent server processes sharing a save are unsupported. See server-saving.md.


## V37 team XP settlement

User approved equal personal XP from recovered team valuables for everyone who departed; waiting arrivals are excluded and failed runs yield none. Eligibility comes from the server's fixed launch participant list, not connection/state at extraction. Downed/caged/offline/expired participants receive the successful-team XP too; ghost/downed bags still do not bank unless teammates actually recovered their items. The same existing sale-value/Hard-rounding calculation produces XP for each participant rather than dividing a pot. Materials/equipment/debug supplies do not produce XP.

Shared gold, cleared sacks and every departed profile's XP are committed together in the existing SQLite home checkpoint before an extraction is acknowledged. The live settled latch plus the existing nonresumable-dungeon restart policy prevents replay; no client command submits XP, profile ownership or a completed run ID. On failed commit the server's V36 fail-closed path pauses without acknowledging a successful escape. After restart, either no reward was committed or bank/profiles were committed together; partial payouts cannot be persisted. A durable run-history ledger is needed if resumable dungeons are added later, not claimed here.

Results reuse personalXp earned/total UI and omit the internal award Map. Offline/expired participants get updated saved balances and a temporary team-XP notice on reconnect; result history is not stored. Purchases stay at existing stations, use only the acting player's balance and retain explicit ownership at zero XP. Smoke crafting still spends shared stock and creates output sack-first; Quick Fingers sets that goblin's search rate when the next dungeon starts. No teammate gains another's knowledge/passive. V36 schema remains compatible.


## V38 operator actions across connected players

User approved server-side test administration. Backups use the same durable home projection as V36 saving. Only local private admin API can issue commands; player WebSockets reject reset/edit messages. Summary lists identities by ID/name plus balances/status, never tokens. Shared-stock/personal-XP edits and all reset/restore commands validate first, back up current state, then update existing live actors and atomically commit. Connected clients receive the new state on the next normal tick. Home poses/readiness/results/held state reset cleanly; identity keys remain valid.

Reset lair preserves personal sacks/profiles; reset goblin affects one profile/sack; reset all clears shared/personal progression but retains identities/backups. Restore retains newer identities at zero progress/empty bags, restores backed-up actors and protects the monotonic home item counter. Stock/XP edits retain unrelated values/ownership and cannot assign negative/fractional/nonfinite values or stock sellable valuables. No edits or restore during active runs. Manual backup remains available then, but does not preserve a live dungeon.

Forced end uses the existing one-time failed settlement path with an explicit aborted flag/result message, no gold/XP, actual abandoned carried-item list, shared run cleanup and home return; waiting sacks/profiles stay intact. Every action that changes data requires a successfully flushed before-change backup. Backup failure leaves live/save state untouched; failed commit latches game/admin mutations closed. The current local-only capability link/Origin/loopback checks are operator tooling, not hosted admin authentication. See server-admin.md for exact scopes and recovery.


## V39 connection hub and lair boundaries

User requested a pre-lair home screen with goblin/level plus create/join by name/code. Server now owns global goblin identities/profiles and one reused lair session engine per named group. One identity has one live connection/current lair, and commands route only there, never to a client-supplied target group. Current group members see its invite code, while home screen only shows names of previously joined lairs. Codes/name matching are case-insensitive; names unique after trimming, control characters/oversize rejected; repeated wrong codes get a short cooldown. No global lair list or account login introduced.

Each group independently owns stock/gold/packed sacks, planning/readiness, dungeon seed/search/loot/guards/alerts and results. Late joiners wait for that group's next run. Leaving a lair removes readiness without spending its saved bag; active participants cannot leave until run close or operator abort. Home reload returns to menu; live in-run disconnect reconnects to same actor/health/bag under existing grace. On expiry or server restart, return to menu and join using code. Personal purchases/XP follow the goblin; all lair actors including offline old-team participants refer to the same canonical profile. Expired participants can join another group while their old team continues; later equal XP awards add to current balance without overwriting purchases.

One payload2 checkpoint commits canonical profiles plus all lair durable home states. Startup migration first backs up the old single-home payload then names it Original Lair, keeping old bags/IDs/profile progress; admin shows generated code. Per-lair item IDs may coincide across groups but commands, ownership and validation remain scoped; counter never rewinds within a group. Admin backs up/restores the whole server, selects group for shared-stock/reset-lair/abort, and handles global personal reset scopes. Any active group run blocks edit/restore; ending selected run doesn't interrupt another. Home level is provisional lifetimeXP-based display only, not a spend/token/gating change.


## V40 owner re-entry

User requested creator access without remembering the invite code. Creation records ownerId from the authenticated goblin, never a client owner field. Menu lists only that goblin's owned lairs and offers dedicated entry by lair ID after checking ownership; friend history excludes these owned entries, and friend joins still validate code. Name-based owner join also bypasses code/cooldown, but only while at the home screen; active run/current-lair restrictions remain unchanged. Profiles/stock/bag isolation and one-connection identity rules retained.

Saved ownerId validates against canonical profile IDs. Before-upgrade backup gates V39 ownership backfill from first saved member; empty groups stay explicitly unowned and cannot be claimed by later visitors. Existing owner metadata survives reset and full backup/restore. Older backup restore preserves known ownership instead of inferring a new owner from a changed roster order. Ownership grants no private server-admin rights.


V41 implementation: run tuning belongs to the selected lair, modified only through existing private local admin access. Saves during a run affect the next departure; the current whole team shares the original snapshot. Other groups are independent. Personal bonuses/difficulty remain layered onto base rules. No player/owner admin privileges added.


V42: dungeon architecture remains a map-table team destination, independent of difficulty. Each lair saves three architecture presets via private admin; settings changed mid-run affect only future departures. Team snapshots contain the immutable launched layout config/seed so joining/reconnecting browsers regenerate identical tiles. Group resource/readiness/recovery rules are unchanged.


## Locked treasure room — V55 implemented

One searched key belongs to the carrying goblin's normal sack and can be shared by dropping it. All teammates see the same closed/open entrances. E beside an entrance uses a matching packed key once; simultaneous or repeated unlocks cannot consume another key or create rewards. Opening is shared for the run, never a vote. Downing/expired disconnect spills the key with ordinary items for teammate recovery. Unused keys cannot be banked/carried between runs; leaving without opening remains allowed. Key container contents/source remain hidden from player snapshots. Guard posts, cages and reinforcement entrances are outside the sealed room, and other escape routes remain connected.

## V81 — Lucky potion

Agreed behaviour: drink Lucky for +5percentage points chance of finding gold coins in your own completed searches for the remainder of this run, one active dose per goblin, no stacking. Actual searching goblin owns the bonus; coins spill into ordinary shared floor loot and contribute normally to the shared haul/personal team XP if recovered. Does not change silver/copper, sale prices or other loot. Damage, searching, successful gear use and down/revive preserve luck; a new run/home vitality reset removes it. Drinking Lucky breaks concealment; later disguise/Vanish may coexist with luck.

Trial recipe:50personal XP, brew1berries+1scrap at the built shared potion station. Recipe persists on goblin, stock on lair, old saves default0new stock. Equip chosen bottle, move, Space/phone Use drinks once. Duplicate doses retain the spare bottle. Shared registry distinguishes run effects from timed concealment; search/gear interruption only clears concealment. Boolean effect appears in authoritative player snapshots and separate LUCKY badge. Guide, recipe/brew cards and tagged free test bottles use existing systems.

Implementation: original container generation/RNG and ordinary searches unchanged. Compute original whole-container probability p of at least one gold coin from empty/count/material/rare/pool probabilities, including depth, tuning and Hard rare bonus. Treasure containers replace normal contents, so p=0there. Only gold-free lucky completions get an independent deterministic coin roll at min(1,.05/(1-p)), giving overall min(1,p+.05). Existing coin searches gain no extra. Success appends one coin, preserving resources, keys and prizes; empty containers may become one item and two-item containers may become three. This is an explicit extra-coin search effect, not a valuable replacement. Roll hashes run seed/container ID separately from original RNG; cancellation, swapping searcher and retries cannot reroll. Only completed server/solo search applies it, with shared searched flag/claim preventing duplicate loot. No client effect/odds/contents fields accepted.
