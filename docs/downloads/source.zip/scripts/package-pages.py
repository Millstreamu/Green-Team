from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
project=Path(__file__).resolve().parent.parent
site=project/'pages'
(site/'downloads').mkdir(exist_ok=True)
with ZipFile(site/'downloads/drawing-templates.zip','w',ZIP_DEFLATED) as z:
 for p in (project/'workshop/templates').rglob('*'):
  if p.is_file() and 'terrain-v2' not in p.parts:z.write(p,str(p.relative_to(project/'workshop/templates')))
with ZipFile(site/'downloads/source.zip','w',ZIP_DEFLATED) as z:
 for name in ['README.md','AGENTS.md','package.json','package-lock.json','index.html','play.html','admin.html','START-HERE.txt']:
  z.write(project/name,name)
 for folder in ['src','server','scripts','tests','docs','assets','workshop','pages-src']:
  for p in (project/folder).rglob('*'):
   if p.is_file() and '__pycache__' not in p.parts and p.name not in ['workshop.html','game-bundle.js']:
    z.write(p,str(p.relative_to(project)))
readme=project/'pages-src/PUBLISHING.md'
if readme.exists():(site/'README.md').write_text(readme.read_text())
output=project.parent/'green-team-github-pages.zip'
with ZipFile(output,'w',ZIP_DEFLATED) as z:
 for p in site.rglob('*'):
  if p.is_file():z.write(p,str(p.relative_to(site)))
with ZipFile(output) as z:
 assert z.testzip() is None
 assert 'index.html' in z.namelist() and 'workshop/index.html' in z.namelist() and '.nojekyll' in z.namelist()
print(f'Packaged {output.name}: {output.stat().st_size:,} bytes')
